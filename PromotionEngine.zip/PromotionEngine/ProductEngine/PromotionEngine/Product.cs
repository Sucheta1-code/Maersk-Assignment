﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine
{
    public class Product
    {
        public static decimal getProductPrice(char product)
        {
            decimal price = 0;
            switch (product)
            {
                case 'A':
                    price = 50;
                    break;
                case 'B':
                    price = 30;
                    break;
                case 'C':
                    price = 20;
                    break;
                case 'D':
                    price = 15;
                    break;
            }
            return price;
        }
    }
}
