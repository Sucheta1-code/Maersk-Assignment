﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine
{
    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {

                string[] iparray = args[0].Split(',');
                ICheckPromotion dicountmodel = new CheckPromotion();
                List<string> cart = new List<string>();
                cart.AddRange(iparray);
                decimal tp = dicountmodel.Activepromotion(cart);
                Console.WriteLine("totalprice:" + tp);
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
        }
    }
}
