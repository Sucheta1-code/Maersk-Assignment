# promotionengine
promotion engine written in c#

#Test scenarios
1. open cmd prompt
2. Navigate to project folder where .exe file is present
3. run the command PromotionEngine [Comma seperated input SKU ID]
eg:  PromotionEngine A,A,A,A,A,B,C,D

