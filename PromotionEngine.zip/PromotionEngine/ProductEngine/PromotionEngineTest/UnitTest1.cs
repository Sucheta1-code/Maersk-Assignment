﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using PromotionEngine;

namespace PromotionEngineTest
{
    [TestClass]
    public class UnitTest1
    {
        private CheckPromotion ds;
        [SetUp]
        public void Setup()
        {
            ds = new CheckPromotion();
        }

        [TestMethod]
        public void ActivePromotionSenarioA_Test()
        {
            //Scenario A-a,b,c
            List<string> sku = new List<string>()
            {
                "a","b","c"
            };

            decimal res = ds.Activepromotion(sku);
            NUnit.Framework.Assert.IsTrue(res == 100, $"Total order value is {res}", sku);
            Console.WriteLine($"Total order value is {res}");

        }

        [TestMethod]
        public void ActivePromotionSenarioB_Test()
        {
            //Scenario B- 5a,5b,c
            List<string> sku = new List<string>()
            {
                "a","a","a","a","a","b","b","b","b","b","c"
            };

            decimal res = ds.Activepromotion(sku);
            NUnit.Framework.Assert.IsTrue(res == 370, $"Total order value is {res}", sku);
            Console.WriteLine($"Total order value is {res}");

        }

        [TestMethod]
        public void ActivePromotionSenarioC_Test()
        {
            //Scenario C- 3a,5b,c,d
            List<string> sku = new List<string>()
            {
                "a","a","a","b","b","b","b","b","c","d"
            };

            decimal res = ds.Activepromotion(sku);
            NUnit.Framework.Assert.IsTrue(res == 280, $"Total order value is {res}", sku);
            Console.WriteLine($"Total order value is {res}");

        }
    }
}
